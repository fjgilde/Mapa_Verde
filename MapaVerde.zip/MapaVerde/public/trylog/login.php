<!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="estilo.css">
        <style>
            .resgistroInicio{
                display: flex; 
                gap: 20px
            }
        </style>
    </head>
    <body>
        <header>
            <nav>
                <div class="logo">Mapa verde</div>
                <ul class="nav-links">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="login.html" class="login-btn">Login</a></li>
                </ul>
            </nav>
        </header>

        <main class="login-main">        
            <form class="login-form" id="formulario" method="post">
                <div id="resgistroInicio" class="resgistroInicio" >
                <h1 id="InicioSesion" onclick="IniciarSesion()">Iniciar Sesión</h1>
                <h1>O</h1>
                <h1 id="Registarse" onclick="RegistarsePag()">Registarse</h1>
                </div>
                <div class="form-group">
                    <label for="username">Usuario:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <div id="textoreg"></div>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <br>
                <button type="submit" id="Iniciar_sesion" name="Iniciar_sesion">Iniciar sesion</button>
                <ul><a href="forgot.html" class="Forgot" id="Forgot">Olvidastes tu Contraseña</a></ul>
            </form>
        </main>
        <p></p>
        <div id="terminos">
        
        </div>
        <br>

        <footer>
            <p>&copy; 2024 Web Responsive. Hecho por Francisco Javier Gutierrez Ildefonso.</p>
        </footer>
        <script>
        let Inicio = document.getElementById("Inicio_Sesion");
        let Resgistro = document.getElementById("Registarse");
        let terminos = document.getElementById("terminos");
        let textReg = document.getElementById("textoreg");
        function RegistarsePag(){
        let btn = document.getElementById("Iniciar_sesion");
        textReg.innerHTML = "<label for='email'>Email: </label><input type='email' id='email' name='email' required>";
        btn.innerHTML = "<button type='submit' id='Registrarse' name='Registrarse'>Registrarse</button>";
        terminos.innerHTML = "<input type='checkbox'> Acepta la politica de uso y los terminos <label for='enlace'>Politicas <a id='enlace' name='enlace'href='#'/>"
        }
        
        function IniciarSesion(){
        textReg.textContent = "";
        terminos.textContent = "";
        let btn = document.getElementById("Registrarse");
        btn.innerHTML = "";
        btn.innerHTML = "<button type='submit' id='Iniciar_sesion' name='Iniciar_sesion>Iniciar sesion</button>";
        }
        </script>
    </body>
    </html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){

    $conn = new mysqli('localhost', 'deltafran@2025', 'Jake2017$', 'userspag');

    if($conn->connect_error){
        die("Error al iniciar sesión: " . $conn->connect_error);
    }

    $user = $_POST['username'];
    $passw = $_POST['password'];

    if ($_POST['Iniciar_sesion'] == 'Iniciar_sesion') {
        $stmt = $conn->prepare("SELECT * FROM list_user_pag WHERE Usuarios = ? AND Password = ?");
        $stmt->bind_param("ss", $user, $passw);
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            echo "Inicio de sesión exitoso.";
        } else {
            echo "Credenciales inválidas.";
        }
    
        $stmt->close();
    } elseif ($_POST['Registrase'] == 'Registrase') {
        $email = $_POST['email'];
        $stmt = $conn->prepare("INSERT INTO list_user_pag (Usuarios, Password, Email) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $user, $passw, $email);
    
        if($stmt->execute()){
            echo "Operación completada. Registro realizado correctamente.";
        } else {
            echo "Error al realizar el registro: " . $conn->error;
        }
    
        $stmt->close();
    } else {
        echo "Acción no reconocida este es el fallo . ";
    }
    
    $conn->close();
    }
?>
